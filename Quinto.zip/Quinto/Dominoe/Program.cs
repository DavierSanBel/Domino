﻿Jugador_Random Yosvany, Yusimy, El_Brayan, Yuniela;
Yosvany = new Jugador_Random("Yosvany");
Yusimy = new Jugador_Random("Yusimy");
El_Brayan = new Jugador_Random("El_Brayan");
Yuniela = new Jugador_Random("Yuniela");
Equipo Titis = new Equipo("Titis", "Yusimy", "Yuniela");
Equipo Tatas = new Equipo("Tatas", "Yosvany", "El_Brayan");
List<Jugador> jugadores = new List<Jugador>(){Yosvany, Yusimy, El_Brayan, Yuniela};
#region Domino_Habitual
Reglas_del_Juego reglas = new Reglas_del_Juego
(new Creador_Usual(), new GameOver_Usual(), new Puntuador_Usual(), new Validador_Usual(),
new Mover_Turno_Usual(), new Refrescador_Usual(),
new List<ICriterio_de_cambio>(){new Criterio_de_cambio_Random()});
Juego juego = new Juego(jugadores, reglas, new Ordenador_Usual(), Titis, Tatas);
foreach(Jugada jugada in juego.Jugar)
{
    Console.WriteLine(jugada);
    Console.ReadKey();
}
foreach(var tupla in juego.Puntuaciones)
    Console.WriteLine(tupla.Key + " " + tupla.Value.ToString());
Console.WriteLine("Ahora 10 000 de juegos de domino habitual, espere un momentillo");
int victorias_de_las_titis = 0, pegadas_de_las_titis = 0;
int victorias_de_los_tatas = 0, pegadas_de_los_tatas = 0;
for(int i = 0; i < 10000; i++)
{
    juego = new Juego(jugadores, reglas, new Ordenador_Usual(), Titis, Tatas);
    foreach(Jugada jugada in juego.Jugar);
    if(juego.Puntuaciones["Titis"] < juego.Puntuaciones["Tatas"])
    {
        victorias_de_las_titis++;
        pegadas_de_las_titis += (juego.Puntuaciones["Titis"] == 0)?1:0;
    }
    if(juego.Puntuaciones["Titis"] > juego.Puntuaciones["Tatas"])
    {
        victorias_de_los_tatas++;
        pegadas_de_los_tatas += (juego.Puntuaciones["Tatas"] == 0)?1:0;
    }
}
Console.WriteLine("Titis : " + victorias_de_las_titis.ToString() + " por pegada " + pegadas_de_las_titis.ToString());
Console.WriteLine("Tatas : " + victorias_de_los_tatas.ToString() + " por pegada " + pegadas_de_los_tatas.ToString());
#endregion
#region Burrito

#endregion
