﻿// See https://aka.ms/new-console-template for more information
public class Program{
public static int Main(){
Jugador_Random Yosvany, Yusimy, El_Brayan, Yuniela;
Yosvany = new Jugador_Random("Yosvany");
Yusimy = new Jugador_Random("Yusimy");
El_Brayan = new Jugador_Random("El_Brayan");
Yuniela = new Jugador_Random("Yuniela");
Equipo Titis = new Equipo("Titis", "Yusimy", "Yuniela");
Equipo Tatas = new Equipo("Tatas", "Yosvany", "El_Brayan");
List<Jugador> jugadores = new List<Jugador>(){Yosvany, Yusimy, El_Brayan, Yuniela};
#region Domino_Habitual
Reglas_del_Juego reglas = new Reglas_del_Juego
(new Creador_Usual(), new GameOver_Usual(), new Puntuador_Usual(), new Validador_Usual(),
new Mover_Turno_Usual(), new Refrescador_Usual());
Juego juego = new Juego(jugadores, reglas, new Ordenador_Usual(), Titis, Tatas);
Console.WriteLine("Ahora jugaremos un juego de domino habitual en parejas");
MostrarJuego(juego);
Console.WriteLine("Ahora 10 000 de juegos de domino habitual, espere un momentillo");
int victorias_de_las_titis = 0, pegadas_de_las_titis = 0;
int victorias_de_los_tatas = 0, pegadas_de_los_tatas = 0;
for(int i = 0; i < 10000; i++)
{
    juego = new Juego(jugadores, reglas, new Ordenador_Usual(), Titis, Tatas);
    foreach(Action accion in juego.Jugar);
    if(juego.Puntuaciones["Titis"] < juego.Puntuaciones["Tatas"])
    {
        victorias_de_las_titis++;
        pegadas_de_las_titis += (juego.Puntuaciones["Titis"] == -1)?1:0;
    }
    if(juego.Puntuaciones["Titis"] > juego.Puntuaciones["Tatas"])
    {
        victorias_de_los_tatas++;
        pegadas_de_los_tatas += (juego.Puntuaciones["Tatas"] == -1)?1:0;
    }
}
Console.WriteLine("Titis : " + victorias_de_las_titis.ToString() + " por pegada " + pegadas_de_las_titis.ToString());
Console.WriteLine("Tatas : " + victorias_de_los_tatas.ToString() + " por pegada " + pegadas_de_los_tatas.ToString());
#endregion
#region Burrito
Console.WriteLine("Ahora un juego de Burrito individual");
reglas = new Reglas_del_Juego
(new Creador_Usual(), new GameOver_del_Burrito(new GameOver_Usual()), new Puntuador_Usual(), 
new Validador_Usual(), new Mover_Turno_Usual(), new Refrescador_del_Burrito(),
10, 6, 2);
juego = new Juego(jugadores, reglas, new Ordenador_Usual());
MostrarJuego(juego);
/*Console.WriteLine("Ahora 10000 juegos de Burrito individual");
Dictionary<string, (int, int)> Victorias = new Dictionary<string, (int, int)>();
foreach(Jugador jugador in jugadores)Victorias.Add(jugador.nombre, (0, 0));
for(int i = 0; i < 10000; i++)
{
    juego = new Juego(jugadores, reglas, new Ordenador_Usual(), Titis, Tatas);
    foreach(Action accion in juego.Jugar);
    foreach(var tupla in juego.Puntuaciones)
    {
        if(tupla.Value <= 0)Victorias[tupla.key].item1++;
        if(tupla.Value == -1)Victorias[tupla.key].item2++;
    }
}PorQue njovtrabajan los Diccionarios??;*/
foreach(var tupla in Victorias)
    Console.WriteLine(tupla.key + " gano " + tupla.value.item1 + ", por pegada " + tupla.value.item2);
#endregion
return 0;
}
static void MostrarJuego(Juego juego)
{
    foreach(Action accion in juego.Jugar)
    {
        Console.WriteLine(accion);
        Console.ReadKey();
    }
    foreach(var tupla in juego.Puntuaciones)
        Console.WriteLine(tupla.Key + " " + tupla.Value.ToString());
}
}