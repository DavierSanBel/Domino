Prueba.Prueba_Usual();
//Prueba.Prueba_Usual("Camaron");
//Prueba.Prueba_Con_Humano();
//Prueba.Prueba_Con_Humano_Del_Camaron();
