public interface IPuntuador_de_Fichas
{
    int Puntuar (Ficha ficha);
}