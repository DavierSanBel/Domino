public interface IPuntuador_de_Manos
{
    int Puntuar (IPuntuador_de_Fichas Puntuador_De_Fichas, List<Ficha> fichas);
}