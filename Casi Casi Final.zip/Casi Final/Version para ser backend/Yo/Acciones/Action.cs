public abstract class Action
{
    public readonly string autor;
    public Action(string autor)
    {
        this.autor = autor;
    }
}