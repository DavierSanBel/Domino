public interface IPuntuador_de_Equipos
{
    int Puntuar (IPuntuador_de_Fichas Puntuador_De_Fichas, IPuntuador_de_Manos Puntuador_De_Manos, Equipo equipo, Portal_del_Banquero banquero);
}