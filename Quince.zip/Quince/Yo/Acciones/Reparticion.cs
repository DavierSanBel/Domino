public class Reparticion : Action
{
    public Reparticion():base(null){}
    public override string ToString()
    {
        return "Se reparten fichas";
    }
}