public interface IPredicado
{
    bool Evaluar(Estado estado, List<Ficha> mano);
}