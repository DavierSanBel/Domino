public interface IGameOver
{
    bool GameOver(Estado estado, List<Ficha> mano_del_ultimo_en_jugar);
}